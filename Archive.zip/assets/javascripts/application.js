function fetchToken (token) {
  console.log('account linking..')
  fetch('http://localhost:3030/get_access_token', {
    method: 'POST',
    headers: {
      'content-type': 'application/json'
    },
    body: JSON.stringify(token)
  })
    .then((res) => res.json())
    .then((data) => console.log(data))
}

function getMyAccessToken () {
  console.log('getting public token..')
  const handler = Plaid.create({
    apiVersion: 'v2',
    clientName: 'Plaid Walkthrough Demo',
    env: 'sandbox',
    product: ['transactions'],
    key: '3460eb74566e0841fe8d0b1369bd9c',
    onSuccess: (publicToken) => {
      console.log(publicToken)
      return fetchToken(publicToken)
    }
  })

  handler.open()
}



// var handler = Plaid.create({
//   apiVersion: 'v2',
//   clientName: 'Plaid Walkthrough Demo',
//   env: '<%= PLAID_ENV %>',
//   product: ['transactions'],
//   key: '<%= PLAID_PUBLIC_KEY %>',
//   onSuccess: function(public_token) {
//     console.log('success')
//     $.post('/get_access_token', {
//       public_token: public_token
//     }, function() {
//       $('#container').fadeOut('fast', function() {
//         $('#intro').hide();
//         $('#app, #steps').fadeIn('slow');
//       });
//     });
//   },
// });